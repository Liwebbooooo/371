/* 汉字闯关 Service Worker：核心壳缓存 + 笔画数据按需缓存 */
const CORE = 'hzq-core-v1', STROKES = 'hzq-strokes-v1';
self.addEventListener('install', e => {
  e.waitUntil(
    caches.open(CORE).then(c => c.addAll(['./', 'index.html', 'data/content.js', 'lib/hanzi-writer.min.js', 'font.css', 'workbench.html']).catch(()=>{}))
      .then(() => self.skipWaiting())
  );
});
self.addEventListener('activate', e => e.waitUntil(self.clients.claim()));
self.addEventListener('fetch', e => {
  if (e.request.method !== 'GET') return;
  const u = new URL(e.request.url);
  if (u.pathname.includes('/data/strokes/')) {
    e.respondWith(
      caches.open(STROKES).then(async c => {
        const hit = await c.match(e.request);
        if (hit) return hit;
        try {
          const r = await fetch(e.request);
          if (r.ok) c.put(e.request, r.clone());
          return r;
        } catch (err) { return hit || Response.error(); }
      })
    );
    return;
  }
  if (/\.(woff2|js|css|html)$/.test(u.pathname)) {
    e.respondWith(
      caches.open(CORE).then(async c => {
        const hit = await c.match(e.request);
        const net = fetch(e.request).then(r => { if (r.ok) c.put(e.request, r.clone()); return r; }).catch(() => hit);
        return hit || net;
      })
    );
  }
});
