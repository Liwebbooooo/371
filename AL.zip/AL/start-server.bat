@echo off
cd /d "%~dp0"
echo 汉字闯关本地服务已启动，同WiFi设备访问：
echo   http://本机IP:8000/
echo 本机IP见 ipconfig（如 192.168.x.x）
start http://localhost:8000/
python -m http.server 8000
pause
