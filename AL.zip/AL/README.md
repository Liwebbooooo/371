# 汉字闯关

部编版小学1-6年级识字表（2948字 · 246关 · 每关12字）闯关学习应用。

玩法：学习（田字格点读＋拼读＋笔顺动画＋课本式注音词句）→ 听写（听音描红笔顺）→ 对对碰（汉字拼音配对消除）；统计页含进度、错字本、导出导入。金币与「乐乐学习工作台」(workbench.html) 共享同一存档，可喂宠物。

## 目录

- index.html 应用主体
- workbench.html 乐乐工作台（同仓同源，金币宠物互通）
- data/content.js 2948字内容＋拼音＋拼读拆分
- data/strokes/ 每字笔画动画数据（2948个小文件）
- lib/hanzi-writer.min.js 笔顺动画库
- font.css + font/ 霞鹜文楷子集（开源字体，SIL协议）
- sw.js 离线缓存；_headers Cloudflare缓存规则

## 部署（GitHub + Cloudflare Pages）

1. 在本目录执行：
   git init
   git add .
   git commit -m "汉字闯关 v1"
   git branch -M main
   git remote add origin https://github.com/你的用户名/仓库名.git
   git push -u origin main
2. Cloudflare 后台 → Workers & Pages → Create → Pages → Connect to Git → 选该仓库。
   构建命令留空，输出目录留空（根目录即站点）。保存并部署。
3. 访问 https://项目名.pages.dev （或在CF绑定自定义域名，国内更稳）。
4. 平板/手机浏览器打开该地址，可"添加到主屏幕"全屏使用；首次建议点右上角"一键缓存"。
5. 想要平板扫码：用任意二维码工具把访问地址生成二维码即可。

公开/私有仓库均可（CF Pages免费版支持私有）。

## 本地离线玩（备用）

双击 start-server.bat（需装Python），同WiFi设备访问提示地址。
或直接浏览器打开 index.html（笔顺数据需联网首次加载，之后走缓存）。

## 数据说明

- 进度存浏览器 localStorage（hanzi-quest-v1），换设备用统计页导出/导入。
- 金币写入 lele-study-workbench-v1（写入前自动备份 -hq-bak 键）。
- 成语均取自成语词典原文；287个无成语字不硬凑，多给组词和造句。
